package com.example.sqllite;

public class onomaModal {
    private int id;
    private String onoma;
    private String eponymo;

    public onomaModal(int id, String onoma, String eponymo) {
        this.id = id;
        this.onoma = onoma;
        this.eponymo = eponymo;
    }

    public int getId() { return id; }
    public String getOnoma() { return onoma; }
    public String getEponymo() { return eponymo; }

    public void setId(int id) { this.id = id; }
    public void setOnoma(String onoma) { this.onoma = onoma; }
    public void setEponymo(String eponymo) { this.eponymo = eponymo; }
}