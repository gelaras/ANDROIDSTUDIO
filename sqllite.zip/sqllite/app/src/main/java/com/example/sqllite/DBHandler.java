package com.example.sqllite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {
    private static final String DB_NAME = "vasi";
    private static final int DB_VERSION = 1;
    private static final String TABLE_NAME = "onomata";
    private static final String ID_COL = "id";
    private static final String NAME_COL = "name";
    private static final String SURNAME_COL = "surname";

    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + NAME_COL + " TEXT,"
                + SURNAME_COL + " TEXT)";
        db.execSQL(query);
    }

    public void addNewName(String onoma, String eponymo) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(NAME_COL, onoma);
        values.put(SURNAME_COL, eponymo);
        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    public ArrayList<onomaModal> getAllNames() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
        ArrayList<onomaModal> namesList = new ArrayList<>();

        if (cursor.moveToFirst()) {
            do {
                namesList.add(new onomaModal(
                        cursor.getInt(0), // id
                        cursor.getString(1), // name
                        cursor.getString(2) // surname
                ));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return namesList;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}