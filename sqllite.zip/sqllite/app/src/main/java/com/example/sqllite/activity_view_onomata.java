package com.example.sqllite;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class activity_view_onomata extends AppCompatActivity {
    private ArrayList<onomaModal> onomaModalArrayList;
    private DBHandler dbHandler;
    private onomaRVadapter onomaRVadapter;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_onomata);

        recyclerView = findViewById(R.id.OnomataRView);
        dbHandler = new DBHandler(this);
        onomaModalArrayList = dbHandler.getAllNames();

        onomaRVadapter = new onomaRVadapter(onomaModalArrayList, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(onomaRVadapter);
    }
}