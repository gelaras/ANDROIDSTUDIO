package com.example.sqllite;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class onomaRVadapter extends RecyclerView.Adapter<onomaRVadapter.ViewHolder> {
    private ArrayList<onomaModal> onomaModalArrayList;
    private Context context;

    public onomaRVadapter(ArrayList<onomaModal> onomaModalArrayList, Context context) {
        this.onomaModalArrayList = onomaModalArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_rv_onomata, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        onomaModal modal = onomaModalArrayList.get(position);
        holder.viewID.setText(String.valueOf(modal.getId()));
        holder.viewOnoma.setText(modal.getOnoma());
        holder.viewEponimo.setText(modal.getEponymo());
    }

    @Override
    public int getItemCount() {
        return onomaModalArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView viewID, viewOnoma, viewEponimo;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            viewID = itemView.findViewById(R.id.viewID);
            viewOnoma = itemView.findViewById(R.id.viewOnoma);
            viewEponimo = itemView.findViewById(R.id.viewEponymo);
        }
    }
}