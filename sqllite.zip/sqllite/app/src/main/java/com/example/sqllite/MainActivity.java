package com.example.sqllite;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private EditText editTextName;
    private EditText editTextSurname;
    private Button button2;
    private Button diavasma;
    private DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Initialize all views
        button2 = findViewById(R.id.button2);
        editTextName = findViewById(R.id.editTextText);
        editTextSurname = findViewById(R.id.editTextText2);
        diavasma = findViewById(R.id.diavasma);
        dbHandler = new DBHandler(MainActivity.this);

        diavasma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, activity_view_onomata.class);
                startActivity(intent);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editTextName.getText().toString();
                String surname = editTextSurname.getText().toString();

                if (name.isEmpty() && surname.isEmpty()) {
                    Toast.makeText(MainActivity.this, "GEMISE kai ta dio pedia", Toast.LENGTH_SHORT).show();
                    return;
                }
                dbHandler.addNewName(name, surname);
                Toast.makeText(MainActivity.this, "proste8ike onoma", Toast.LENGTH_SHORT).show();
                editTextName.setText("");
                editTextSurname.setText("");
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}